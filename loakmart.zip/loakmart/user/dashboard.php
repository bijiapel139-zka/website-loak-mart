
<?php
require_once '../config/database.php';
require_once '../config/auth.php';

wajibLogin();

$userId = (int) $_SESSION['user']['id'];
$nama = $_SESSION['user']['nama'] ?? 'Pengguna';
$role = $_SESSION['user']['role'] ?? 'user';

if ($role === 'admin') {
    header('Location: ../admin/dashboard.php');
    exit;
}

// Jumlah barang milik pengguna
$stmt = $pdo->prepare("
    SELECT COUNT(*) FROM barang WHERE user_id = ?
");
$stmt->execute([$userId]);
$totalBarang = (int) $stmt->fetchColumn();

// Jumlah pesanan masuk sebagai penjual
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM detail_transaksi
    WHERE penjual_id = ?
");
$stmt->execute([$userId]);
$totalPesananMasuk = (int) $stmt->fetchColumn();

// Jumlah transaksi sebagai pembeli
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM transaksi
    WHERE pembeli_id = ?
");
$stmt->execute([$userId]);
$totalPembelian = (int) $stmt->fetchColumn();

// Jumlah barang tersedia
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM barang
    WHERE user_id = ? AND status = 'tersedia'
");
$stmt->execute([$userId]);
$totalTersedia = (int) $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Pengguna - LoakMart</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
            gap: 18px;
            margin: 25px 0;
        }

        .dashboard-stat {
            background: white;
            padding: 22px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,.06);
        }

        .dashboard-stat h3 {
            margin: 0 0 12px;
            font-size: 15px;
            color: #666;
        }

        .dashboard-stat strong {
            font-size: 28px;
            color: #222;
        }

        .dashboard-menu {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
        }

        .dashboard-menu a {
            display: block;
            padding: 16px;
            background: white;
            border-radius: 10px;
            text-decoration: none;
            color: #222;
            border: 1px solid #eee;
        }

        .dashboard-menu a:hover {
            background: #f3f7f4;
        }
    </style>
</head>
<body class="seller-body">

<div class="seller-container">

    <h2>Dashboard LoakMart</h2>

    <p>
        Selamat datang,
        <strong><?= htmlspecialchars($nama) ?></strong>!
    </p>

    <p>Kelola aktivitas jual beli Anda melalui dashboard ini.</p>

    <div class="dashboard-grid">

        <div class="dashboard-stat">
            <h3>Total Barang Saya</h3>
            <strong><?= $totalBarang ?></strong>
        </div>

        <div class="dashboard-stat">
            <h3>Barang Tersedia</h3>
            <strong><?= $totalTersedia ?></strong>
        </div>

        <div class="dashboard-stat">
            <h3>Pesanan Masuk</h3>
            <strong><?= $totalPesananMasuk ?></strong>
        </div>

        <div class="dashboard-stat">
            <h3>Total Pembelian</h3>
            <strong><?= $totalPembelian ?></strong>
        </div>

    </div>

    <h3>Menu Pengguna</h3>

    <div class="dashboard-menu">
        <a href="../index.php">Beranda / Belanja</a>
        <a href="jual-barang.php">Jual Barang</a>
        <a href="barang-saya.php">Barang Saya</a>
        <a href="pesanan-masuk.php">Pesanan Masuk</a>
        <a href="keranjang.php">Keranjang</a>
        <a href="riwayat-transaksi.php">Riwayat Transaksi</a>
        <a href="../proses/logout-proses.php">Logout</a>
    </div>

</div>

</body>
</html>
