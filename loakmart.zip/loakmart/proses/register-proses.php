
<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../register.php");
    exit;
}

if (!validasiCSRF()) {
    die("Permintaan tidak valid. Silakan muat ulang halaman.");
}

$nama = trim($_POST['nama'] ?? '');
$email = strtolower(trim($_POST['email'] ?? ''));
$no_hp = trim($_POST['no_hp'] ?? '');
$alamat = trim($_POST['alamat'] ?? '');
$password = $_POST['password'] ?? '';
$konfirmasi = $_POST['konfirmasi_password'] ?? '';

// Validasi data
if ($nama === '' || $email === '' || $password === '') {
    setFlash('error', 'Semua data wajib harus diisi.');
    header("Location: ../register.php");
    exit;
}

if (strlen($nama) > 100 || strlen($email) > 100 ||
    strlen($no_hp) > 20) {
    setFlash('error', 'Data yang dimasukkan terlalu panjang.');
    header("Location: ../register.php");
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    setFlash('error', 'Format email tidak valid.');
    header("Location: ../register.php");
    exit;
}

if (strlen($password) < 8) {
    setFlash('error', 'Password minimal 8 karakter.');
    header("Location: ../register.php");
    exit;
}

if ($password !== $konfirmasi) {
    setFlash('error', 'Konfirmasi password tidak cocok.');
    header("Location: ../register.php");
    exit;
}

try {

    // Memeriksa email
    $cek = $pdo->prepare(
        "SELECT id FROM users WHERE email = ?"
    );

    $cek->execute([$email]);

    if ($cek->fetch()) {
        setFlash('error', 'Email sudah terdaftar.');
        header("Location: ../register.php");
        exit;
    }

    // Mengamankan password
    $passwordHash = password_hash(
        $password,
        PASSWORD_DEFAULT
    );

    // Menyimpan pengguna
    $sql = "INSERT INTO users
            (nama, email, password, no_hp, alamat)
            VALUES (?, ?, ?, ?, ?)";

    $stmt = $pdo->prepare($sql);

    $stmt->execute([
        $nama,
        $email,
        $passwordHash,
        $no_hp,
        $alamat
    ]);

    setFlash('success', 'Registrasi berhasil. Silakan login.');

    header("Location: ../login.php");
    exit;

} catch (PDOException $e) {

    error_log($e->getMessage());

    setFlash('error', 'Registrasi gagal. Silakan coba lagi.');

    header("Location: ../register.php");
    exit;
}
