
<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/auth.php';

// Kode query barang sebelumnya tetap digunakan.

$stmt = $pdo->query("
    SELECT barang.*, kategori.nama_kategori, users.nama
    FROM barang
    INNER JOIN kategori ON barang.kategori_id = kategori.id
    INNER JOIN users ON barang.user_id = users.id
    WHERE barang.status = 'tersedia'
    ORDER BY barang.created_at DESC
");

$barang = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>LoakMart - Jual Beli Barang Loakan</title>

    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<header class="navbar">
    <div class="container nav-content">

        <a href="index.php" class="logo">
            Loak<span>Mart.</span>
        </a>

        <nav>
            <a href="index.php">Beranda</a>
            <a href="#kategori">Kategori</a>
            <a href="#produk">Produk</a>
            <a href="katalog.php">Katalog</a>
        </nav>

        
<div class="nav-button">

   
<?php if (sudahLogin()): ?>

    <span>
        Halo, <?= htmlspecialchars($_SESSION['user']['nama']) ?>
    </span>

    <a href="user/barang-saya.php" class="btn-login">
        Barang Saya
    </a>

    <a href="user/jual-barang.php" class="btn-register">
        + Jual Barang
    </a>

    <a href="user/keranjang.php">Keranjang</a>

    <a href="user/riwayat-transaksi.php">Riwayat Transaksi</a>

    <a href="user/pesanan-masuk.php">Pesanan Masuk</a>

    <form action="proses/logout-proses.php" method="POST">

        <input
            type="hidden"
            name="csrf_token"
            value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"
        >

        <button type="submit" class="btn-logout">
            Keluar
        </button>

    </form>

<?php else: ?>

    <a href="login.php" class="btn-login">
        Masuk
    </a>

    <a href="register.php" class="btn-register">
        Daftar
    </a>

<?php endif; ?>


</div>


    </div>
</header>

<section class="hero">
    <div class="container hero-content">

        <div class="hero-text">
            <h1>
                Barang Bekas,
                <span>Nilai Baru.</span>
            </h1>

            <p>
                Temukan dan jual berbagai barang loakan
                dengan mudah, praktis, dan terjangkau.
            </p>

            <a href="#produk" class="btn-primary">
                Mulai Belanja
            </a>
        </div>

        <div class="hero-image">
            <img
                src="assets/images/loakmart.png"
                alt="Barang bekas"
            >
        </div>

    </div>
</section>

<section class="categories container" id="kategori">

    <h2>Kategori Barang</h2>
    <p class="section-desc">
        Temukan barang sesuai kebutuhanmu.
    </p>

    <div class="category-list">

        <div class="category-item">Besi dan Logam</div>
        <div class="category-item">Plastik</div>
        <div class="category-item">Kardus</div>
        <div class="category-item">Elektronik</div>
        <div class="category-item">Botol dan Kaca</div>
        <div class="category-item">Lainnya</div>

    </div>

</section>

<section class="products container" id="produk">

    <h2>Barang Terbaru</h2>
    <p class="section-desc">
        Produk loakan yang tersedia saat ini.
    </p>

    <div class="product-list">

        <?php if (count($barang) > 0): ?>

            <?php foreach ($barang as $item): ?>

                <div class="product-card">

                    <?php if (!empty($item['foto'])): ?>
                        <img
                            src="uploads/barang/<?= htmlspecialchars($item['foto']) ?>"
                            alt="<?= htmlspecialchars($item['nama_barang']) ?>"
                        >
                    <?php else: ?>
                        <div class="no-image">
                            Tidak ada foto
                        </div>
                    <?php endif; ?>

                    <div class="product-info">

                        <span class="product-category">
                            <?= htmlspecialchars($item['nama_kategori']) ?>
                        </span>

                        <h3>
                            <?= htmlspecialchars($item['nama_barang']) ?>
                        </h3>

                        <p class="price">
                            Rp <?= number_format($item['harga'], 0, ',', '.') ?>
                        </p>

                        <p class="seller">
                            Penjual: <?= htmlspecialchars($item['nama']) ?>
                        </p>

                        <a
                            href="detail.php?id=<?= (int) $item['id'] ?>"
                            class="btn-detail"
                        >
                            Lihat Detail
                        </a>

                    </div>
                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <p class="empty-product">
                Belum ada barang yang dijual.
            </p>

        <?php endif; ?>

        <a href="katalog.php" class="btn-katalog">
    Jelajahi Katalog
</a>

    </div>

</section>

<footer>
    <div class="container">
        <h3>LoakMart.</h3>
        <p>
            Marketplace jual beli barang bekas dan loakan.
        </p>
        <p>&copy; <?= date('Y') ?> LoakMart. All Rights Reserved.</p>
    </div>
</footer>

</body>
</html>
