
<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION['user']['id'];

$success = getFlash('success');
$error = getFlash('error');

$stmt = $pdo->prepare("
    SELECT barang.*, kategori.nama_kategori
    FROM barang
    INNER JOIN kategori
        ON barang.kategori_id = kategori.id
    WHERE barang.user_id = ?
    ORDER BY barang.created_at DESC
");

$stmt->execute([$userId]);

$barang = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Barang Saya - LoakMart</title>

    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="seller-body">

<div class="seller-container">

    <div class="seller-header">

        <div>
            <a href="../index.php" class="logo">
                Loak<span>Mart.</span>
            </a>

            <h2>Barang Saya</h2>

            <p>Kelola semua barang yang kamu jual.</p>
        </div>

        <a href="jual-barang.php" class="add-button">
            + Jual Barang
        </a>

    </div>

    <?php if ($success): ?>
        <div class="success-alert">
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <div class="my-product-list">

        <?php if (count($barang) > 0): ?>

            <?php foreach ($barang as $item): ?>

                <div class="my-product-card">

                    <?php if (!empty($item['foto'])): ?>

                        <img
                            src="../uploads/barang/<?= rawurlencode($item['foto']) ?>"
                            alt="<?= htmlspecialchars($item['nama_barang']) ?>"
                        >

                    <?php else: ?>

                        <div class="no-image">
                            Tidak ada foto
                        </div>

                    <?php endif; ?>

                    <div class="my-product-info">

                        <span class="product-category">
                            <?= htmlspecialchars($item['nama_kategori']) ?>
                        </span>

                        <h3>
                            <?= htmlspecialchars($item['nama_barang']) ?>
                        </h3>

                        <p class="price">
                            Rp <?= number_format($item['harga'], 0, ',', '.') ?>
                        </p>

                        <p>
                            Kondisi:
                            <?= htmlspecialchars($item['kondisi']) ?>
                        </p>

                        <p>
                            Stok:
                            <?= (int)$item['stok'] ?>
                        </p>

                        <p>
                            Status:
                            <?= htmlspecialchars($item['status']) ?>
                        </p>

                        <div class="product-actions">

                            <a
                                href="edit-barang.php?id=<?= (int)$item['id'] ?>"
                                class="edit-button"
                            >
                                Edit
                            </a>

                            <form
                                action="../proses/barang-proses.php"
                                method="POST"
                                onsubmit="return confirm('Yakin ingin menghapus barang ini?')"
                            >

                                <input
                                    type="hidden"
                                    name="aksi"
                                    value="hapus"
                                >

                                <input
                                    type="hidden"
                                    name="id"
                                    value="<?= (int)$item['id'] ?>"
                                >

                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"
                                >

                                <button type="submit" class="delete-button">
                                    Hapus
                                </button>

                            </form>

                        </div>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="empty-state">
                <h3>Belum Ada Barang</h3>

                <p>
                    Kamu belum memasang barang untuk dijual.
                </p>

                <a href="jual-barang.php" class="add-button">
                    Mulai Jual Barang
                </a>
            </div>

        <?php endif; ?>

    </div>

</div>

</body>
</html>
