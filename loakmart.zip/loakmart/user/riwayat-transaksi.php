
<?php
require_once '../config/database.php';
require_once '../config/auth.php';

wajibLogin();

$userId = (int) $_SESSION['user']['id'];

$stmt = $pdo->prepare("
    SELECT id, kode_transaksi, total_harga,
           metode_pembayaran, status, created_at
    FROM transaksi
    WHERE pembeli_id = ?
    ORDER BY created_at DESC
");
$stmt->execute([$userId]);
$transaksi = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Riwayat Transaksi - LoakMart</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="seller-body">
<div class="seller-container">

    <h2>Riwayat Transaksi</h2>

    <?php if ($pesan = getFlash('success')): ?>
        <p class="alert-success">
            <?= htmlspecialchars($pesan) ?>
        </p>
    <?php endif; ?>

    <?php if ($pesan = getFlash('error')): ?>
        <p class="alert-error">
            <?= htmlspecialchars($pesan) ?>
        </p>
    <?php endif; ?>

    <?php if (!$transaksi): ?>
        <div class="seller-card">
            <p>Belum ada transaksi.</p>
            <a href="../index.php">Mulai Belanja</a>
        </div>
    <?php else: ?>

        <?php foreach ($transaksi as $item): ?>
            <div class="seller-card">
                <h3>
                    <?= htmlspecialchars($item['kode_transaksi']) ?>
                </h3>

                <p>
                    Tanggal:
                    <?= htmlspecialchars($item['created_at']) ?>
                </p>

                <p>
                    Total:
                    <strong>
                        Rp<?= number_format(
                            $item['total_harga'], 0, ',', '.'
                        ) ?>
                    </strong>
                </p>

                <p>
                    Pembayaran:
                    <?= htmlspecialchars($item['metode_pembayaran']) ?>
                </p>

                <p>
                    Status:
                    <?= htmlspecialchars($item['status']) ?>
                </p>
            </div>
        <?php endforeach; ?>

    <?php endif; ?>

    <a href="dashboard.php">Kembali ke Dashboard</a>
</div>
</body>
</html>
