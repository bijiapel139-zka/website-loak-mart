
<?php
require_once 'config/database.php';
require_once 'config/auth.php';

wajibLogin();

$role = $_SESSION['user']['role'] ?? 'user';

if ($role === 'admin') {
    header('Location: admin/dashboard.php');
    exit;
}

header('Location: user/dashboard.php');
exit;
