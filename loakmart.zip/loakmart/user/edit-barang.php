
<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

$userId = (int) $_SESSION['user']['id'];
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    die("ID barang tidak valid.");
}

// Mengambil barang milik pengguna
$stmt = $pdo->prepare("
    SELECT *
    FROM barang
    WHERE id = ? AND user_id = ?
");

$stmt->execute([$id, $userId]);

$barang = $stmt->fetch();

if (!$barang) {
    die("Barang tidak ditemukan atau bukan milik Anda.");
}

// Mengambil kategori
$kategori = $pdo->query("
    SELECT * FROM kategori
    ORDER BY nama_kategori ASC
")->fetchAll();

$pesan = getFlash('error');

?>

<!DOCTYPE html>
<html lang="id">
<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edit Barang - LoakMart</title>

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body class="seller-body">

<div class="seller-container">

    <div class="seller-header">

        <div>
            <a href="../index.php" class="logo">
                Loak<span>Mart.</span>
            </a>

            <h2>Edit Barang</h2>

            <p>Perbarui informasi barang yang kamu jual.</p>
        </div>

        <a href="barang-saya.php" class="back-button">
            Kembali
        </a>

    </div>

    <div class="seller-card">

        <?php if ($pesan): ?>
            <div class="alert">
                <?= htmlspecialchars($pesan) ?>
            </div>
        <?php endif; ?>

        <form
            action="../proses/barang-proses.php"
            method="POST"
            enctype="multipart/form-data"
        >

            <input type="hidden" name="aksi" value="edit">

            <input
                type="hidden"
                name="id"
                value="<?= (int)$barang['id'] ?>"
            >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"
            >

            <div class="form-group">

                <label>Nama Barang</label>

                <input
                    type="text"
                    name="nama_barang"
                    value="<?= htmlspecialchars($barang['nama_barang']) ?>"
                    maxlength="150"
                    required
                >

            </div>

            <div class="form-group">

                <label>Kategori</label>

                <select name="kategori_id" required>

                    <?php foreach ($kategori as $k): ?>

                        <option
                            value="<?= (int)$k['id'] ?>"
                            <?= $barang['kategori_id'] == $k['id'] ? 'selected' : '' ?>
                        >

                            <?= htmlspecialchars($k['nama_kategori']) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <div class="form-group">

                <label>Deskripsi</label>

                <textarea name="deskripsi" rows="5"><?= htmlspecialchars($barang['deskripsi'] ?? '') ?></textarea>

            </div>

            <div class="form-group">

                <label>Harga Barang</label>

                <input
                    type="number"
                    name="harga"
                    min="0"
                    step="0.01"
                    value="<?= htmlspecialchars((string)$barang['harga']) ?>"
                    required
                >

            </div>

            <div class="form-group">

                <label>Kondisi</label>

                <select name="kondisi" required>

                    <?php
                    $kondisiList = [
                        'Baru',
                        'Bekas Bagus',
                        'Bekas Normal',
                        'Rusak'
                    ];
                    ?>

                    <?php foreach ($kondisiList as $kondisi): ?>

                        <option
                            value="<?= $kondisi ?>"
                            <?= $barang['kondisi'] === $kondisi ? 'selected' : '' ?>
                        >
                            <?= $kondisi ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>

            <div class="form-group">

                <label>Stok</label>

                <input
                    type="number"
                    name="stok"
                    min="1"
                    max="100000"
                    value="<?= (int)$barang['stok'] ?>"
                    required
                >

            </div>

            <div class="form-group">

                <label>Foto Saat Ini</label>

                <?php if (!empty($barang['foto'])): ?>

                    <img
                        src="../uploads/barang/<?= rawurlencode($barang['foto']) ?>"
                        class="preview-foto"
                        alt="Foto barang"
                    >

                <?php else: ?>

                    <p>Belum ada foto.</p>

                <?php endif; ?>

            </div>

            <div class="form-group">

                <label>Ganti Foto (Opsional)</label>

                <input
                    type="file"
                    name="foto"
                    accept=".jpg,.jpeg,.png,.webp"
                >

                <small>
                    Kosongkan jika tidak ingin mengganti foto.
                    Maksimal 2 MB.
                </small>

            </div>

            <button type="submit" class="seller-submit">
                Simpan Perubahan
            </button>

        </form>

    </div>

</div>

</body>
</html>
