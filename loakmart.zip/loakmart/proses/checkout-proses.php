
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function kembaliCheckout($pesan) {
    setFlash('error', $pesan);
    header('Location: ../checkout.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../user/keranjang.php');
    exit;
}

if (empty($_SESSION['user']['id'])) {
    header('Location: ../login.php');
    exit;
}

if (!validasiCSRF()) {
    kembaliCheckout('Permintaan tidak valid. Silakan coba lagi.');
}

$userId = (int) $_SESSION['user']['id'];
$alamat = trim($_POST['alamat_pengiriman'] ?? '');
$noHp = trim($_POST['no_hp'] ?? '');
$metode = $_POST['metode_pembayaran'] ?? '';

if ($alamat === '' || mb_strlen($alamat) > 2000) {
    kembaliCheckout('Alamat pengiriman tidak valid.');
}

if (!preg_match('/^[0-9+\-\s]{8,20}$/', $noHp)) {
    kembaliCheckout('Nomor HP tidak valid.');
}

if (!in_array($metode, ['COD', 'Transfer Manual'], true)) {
    kembaliCheckout('Metode pembayaran tidak valid.');
}

try {
    $pdo->beginTransaction();

    // Ambil isi keranjang dan kunci barisnya.
    $stmt = $pdo->prepare("
        SELECT id, barang_id, jumlah
        FROM keranjang
        WHERE user_id = ?
        ORDER BY barang_id
        FOR UPDATE
    ");
    $stmt->execute([$userId]);
    $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$cartItems) {
        throw new Exception('Keranjang kosong.');
    }

    $detailPesanan = [];
    $total = 0;

    // Kunci dan periksa setiap barang secara berurutan.
    $stmtBarang = $pdo->prepare("
        SELECT id, user_id, nama_barang, harga, stok, status
        FROM barang
        WHERE id = ?
        FOR UPDATE
    ");

    foreach ($cartItems as $cart) {
        $stmtBarang->execute([(int) $cart['barang_id']]);
        $barang = $stmtBarang->fetch(PDO::FETCH_ASSOC);

        if (!$barang || $barang['status'] !== 'tersedia') {
            throw new Exception('Ada barang yang sudah tidak tersedia.');
        }

        if ((int) $barang['user_id'] === $userId) {
            throw new Exception('Anda tidak dapat membeli barang sendiri.');
        }

        $jumlah = (int) $cart['jumlah'];
        $stok = (int) $barang['stok'];

        if ($jumlah < 1 || $jumlah > $stok) {
            throw new Exception(
                'Stok ' . $barang['nama_barang'] . ' tidak mencukupi.'
            );
        }

        $harga = (float) $barang['harga'];
        $subtotal = $harga * $jumlah;
        $total += $subtotal;

        $detailPesanan[] = [
            'barang_id' => (int) $barang['id'],
            'penjual_id' => (int) $barang['user_id'],
            'nama_barang' => $barang['nama_barang'],
            'harga' => $harga,
            'jumlah' => $jumlah,
            'subtotal' => $subtotal,
            'stok_baru' => $stok - $jumlah
        ];
    }

    // Simpan transaksi utama.
    $kode = 'LM' . date('YmdHis') . strtoupper(bin2hex(random_bytes(3)));

    $stmt = $pdo->prepare("
        INSERT INTO transaksi
        (kode_transaksi, pembeli_id, total_harga,
         alamat_pengiriman, no_hp, metode_pembayaran)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $kode, $userId, $total, $alamat, $noHp, $metode
    ]);

    $transaksiId = (int) $pdo->lastInsertId();

    // Simpan detail, lalu kurangi stok.
    $stmtDetail = $pdo->prepare("
        INSERT INTO detail_transaksi
        (transaksi_id, barang_id, penjual_id, nama_barang,
         harga, jumlah, subtotal)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmtStok = $pdo->prepare("
        UPDATE barang
        SET stok = ?,
            status = CASE WHEN ? <= 0 THEN 'habis' ELSE 'tersedia' END
        WHERE id = ?
    ");

    foreach ($detailPesanan as $item) {
        $stmtDetail->execute([
            $transaksiId,
            $item['barang_id'],
            $item['penjual_id'],
            $item['nama_barang'],
            $item['harga'],
            $item['jumlah'],
            $item['subtotal']
        ]);

        $stmtStok->execute([
            $item['stok_baru'],
            $item['stok_baru'],
            $item['barang_id']
        ]);
    }

    // Kosongkan keranjang pembeli.
    $stmt = $pdo->prepare("DELETE FROM keranjang WHERE user_id = ?");
    $stmt->execute([$userId]);

    $pdo->commit();

    setFlash('success', 'Pesanan berhasil dibuat. Kode: ' . $kode);
    header('Location: ../user/riwayat-transaksi.php');
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log('Checkout LoakMart: ' . $e->getMessage());

    setFlash('error', $e instanceof Exception
        ? $e->getMessage()
        : 'Checkout gagal. Silakan coba kembali.');

    header('Location: ../checkout.php');
    exit;
}
