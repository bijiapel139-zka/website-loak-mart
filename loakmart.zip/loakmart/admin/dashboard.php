
<?php
require_once '../config/database.php';
require_once '../config/auth.php';

wajibLogin();

$role = $_SESSION['user']['role'] ?? 'user';

if ($role !== 'admin') {
    header('Location: ../user/dashboard.php');
    exit;
}

$nama = $_SESSION['user']['nama'] ?? 'Administrator';

// Statistik pengguna
$totalPengguna = (int) $pdo->query("
    SELECT COUNT(*) FROM users
")->fetchColumn();

// Statistik barang
$totalBarang = (int) $pdo->query("
    SELECT COUNT(*) FROM barang
")->fetchColumn();

// Statistik transaksi
$totalTransaksi = (int) $pdo->query("
    SELECT COUNT(*) FROM transaksi
")->fetchColumn();

// Transaksi menunggu
$totalMenunggu = (int) $pdo->query("
    SELECT COUNT(*) FROM transaksi
    WHERE status = 'menunggu'
")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard Admin - LoakMart</title>
    <link rel="stylesheet" href="../assets/css/style.css">

    <style>
        .admin-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
            gap: 18px;
            margin: 25px 0;
        }

        .admin-stat {
            background: white;
            padding: 22px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,.06);
        }

        .admin-stat p {
            color: #666;
        }

        .admin-stat strong {
            font-size: 28px;
        }

        .admin-menu {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 12px;
        }

        .admin-menu a {
            display: block;
            background: white;
            padding: 17px;
            color: #222;
            text-decoration: none;
            border-radius: 10px;
            border: 1px solid #eee;
        }

        .admin-menu a:hover {
            background: #f3f7f4;
        }
    </style>
</head>
<body class="seller-body">

<div class="seller-container">

    <h2>Dashboard Administrator</h2>

    <p>
        Selamat datang,
        <strong><?= htmlspecialchars($nama) ?></strong>!
    </p>

    <p>Panel pengelolaan marketplace LoakMart.</p>

    <div class="admin-grid">

        <div class="admin-stat">
            <p>Total Pengguna</p>
            <strong><?= $totalPengguna ?></strong>
        </div>

        <div class="admin-stat">
            <p>Total Barang</p>
            <strong><?= $totalBarang ?></strong>
        </div>

        <div class="admin-stat">
            <p>Total Transaksi</p>
            <strong><?= $totalTransaksi ?></strong>
        </div>

        <div class="admin-stat">
            <p>Pesanan Menunggu</p>
            <strong><?= $totalMenunggu ?></strong>
        </div>

    </div>

    <h3>Menu Administrator</h3>

    <div class="admin-menu">
        <a href="../index.php">Beranda</a>
        <a href="pengguna.php">Manajemen Pengguna</a>
        <a href="barang.php">Manajemen Barang</a>
        <a href="transaksi.php">Manajemen Transaksi</a>
        <a href="../proses/logout-proses.php">Logout</a>
        <a href="../dashboard.php">Kembali ke Dashboard</a>
    </div>

</div>

</body>
</html>
