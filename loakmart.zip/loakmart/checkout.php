
<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/auth.php';

if (empty($_SESSION['user']['id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user']['id'];

$error = getFlash('error');
$success = getFlash('success');

// Ambil seluruh barang dari keranjang.
$stmt = $pdo->prepare("
    SELECT
        k.id AS keranjang_id,
        k.barang_id,
        k.jumlah,
        b.nama_barang,
        b.harga,
        b.stok,
        b.foto,
        b.status
    FROM keranjang k
    INNER JOIN barang b ON k.barang_id = b.id
    WHERE k.user_id = ?
    ORDER BY k.id DESC
");

$stmt->execute([$userId]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Jika keranjang kosong.
if (!$items) {
    header('Location: user/keranjang.php');
    exit;
}

$total = 0;

foreach ($items as $item) {
    $total += (float) $item['harga'] * (int) $item['jumlah'];
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Checkout - LoakMart</title>

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        .checkout-container {
            width: 90%;
            max-width: 1100px;
            margin: 40px auto;
        }

        .checkout-container h1 {
            margin-bottom: 25px;
            color: #176b45;
        }

        .checkout-layout {
            display: grid;
            grid-template-columns: 1.3fr 1fr;
            gap: 25px;
            align-items: start;
        }

        .checkout-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.07);
        }

        .checkout-card h2 {
            font-size: 20px;
            margin-bottom: 20px;
            color: #176b45;
        }

        .checkout-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }

        .checkout-item img {
            width: 85px;
            height: 85px;
            object-fit: cover;
            border-radius: 8px;
        }

        .item-info {
            flex: 1;
        }

        .item-info h3 {
            font-size: 16px;
            margin-bottom: 6px;
        }

        .item-info p {
            color: #666;
            font-size: 14px;
            margin: 4px 0;
        }

        .item-subtotal {
            font-weight: bold;
            white-space: nowrap;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 7px;
            font-size: 14px;
            font-family: inherit;
        }

        .form-group textarea {
            min-height: 110px;
            resize: vertical;
        }

        .total-row {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            padding-top: 18px;
            border-top: 1px solid #ddd;
            font-size: 19px;
            font-weight: bold;
        }

        .total-price {
            color: #176b45;
        }

        .checkout-button {
            width: 100%;
            padding: 14px;
            margin-top: 22px;
            border: none;
            border-radius: 8px;
            background: #176b45;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .checkout-button:hover {
            background: #218653;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #176b45;
            text-decoration: none;
            font-weight: bold;
        }

        .alert {
            padding: 13px;
            margin-bottom: 18px;
            border-radius: 7px;
        }

        .alert-error {
            background: #ffe5e5;
            color: #b42318;
        }

        .alert-success {
            background: #e1f5e8;
            color: #176b45;
        }

        @media (max-width: 700px) {
            .checkout-layout {
                grid-template-columns: 1fr;
            }

            .checkout-card {
                padding: 18px;
            }

            .checkout-item img {
                width: 70px;
                height: 70px;
            }
        }
    </style>
</head>

<body>

<div class="checkout-container">

    <a href="user/keranjang.php" class="back-link">
        &larr; Kembali ke Keranjang
    </a>

    <h1>Checkout Pesanan</h1>

    <?php if ($error): ?>
        <div class="alert alert-error">
            <?= e($error) ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <?= e($success) ?>
        </div>
    <?php endif; ?>

    <div class="checkout-layout">

        <!-- RINGKASAN BARANG -->
        <div class="checkout-card">

            <h2>Ringkasan Belanja</h2>

            <?php foreach ($items as $item): ?>

                <?php
                $subtotal = (float) $item['harga'] * (int) $item['jumlah'];

                $foto = !empty($item['foto'])
                    ? 'uploads/barang/' . rawurlencode(basename($item['foto']))
                    : 'assets/images/no-image.png';
                ?>

                <div class="checkout-item">

                    <img
                        src="<?= e($foto) ?>"
                        alt="<?= e($item['nama_barang']) ?>"
                        onerror="this.onerror=null;this.src='assets/images/no-image.png';"
                    >

                    <div class="item-info">

                        <h3><?= e($item['nama_barang']) ?></h3>

                        <p>
                            Harga:
                            Rp<?= number_format((float) $item['harga'], 0, ',', '.') ?>
                        </p>

                        <p>
                            Jumlah: <?= (int) $item['jumlah'] ?>
                        </p>

                        <p>
                            Stok tersedia: <?= (int) $item['stok'] ?>
                        </p>

                    </div>

                    <div class="item-subtotal">
                        Rp<?= number_format($subtotal, 0, ',', '.') ?>
                    </div>

                </div>

            <?php endforeach; ?>

            <div class="total-row">
                <span>Total Pembayaran</span>

                <span class="total-price">
                    Rp<?= number_format($total, 0, ',', '.') ?>
                </span>
            </div>

        </div>

        <!-- FORMULIR PEMBELIAN -->
        <div class="checkout-card">

            <h2>Informasi Pengiriman</h2>

            <form action="proses/checkout-proses.php" method="POST">

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= e($_SESSION['csrf_token'] ?? '') ?>"
                >

                <div class="form-group">

                    <label for="alamat_pengiriman">
                        Alamat Lengkap
                    </label>

                    <textarea
                        id="alamat_pengiriman"
                        name="alamat_pengiriman"
                        placeholder="Masukkan alamat lengkap pengiriman..."
                        maxlength="2000"
                        required
                    ></textarea>

                </div>

                <div class="form-group">

                    <label for="no_hp">
                        Nomor HP
                    </label>

                    <input
                        type="tel"
                        id="no_hp"
                        name="no_hp"
                        placeholder="Contoh: 081234567890"
                        minlength="8"
                        maxlength="20"
                        pattern="[0-9+\- ]{8,20}"
                        required
                    >

                </div>

                <div class="form-group">

                    <label for="metode_pembayaran">
                        Metode Pembayaran
                    </label>

                    <select
                        id="metode_pembayaran"
                        name="metode_pembayaran"
                        required
                    >

                        <option value="">Pilih Pembayaran</option>

                        <option value="COD">
                            COD (Bayar di Tempat)
                        </option>

                        <option value="Transfer Manual">
                            Transfer Manual
                        </option>

                    </select>

                </div>

                <div class="total-row">
                    <span>Total</span>

                    <span class="total-price">
                        Rp<?= number_format($total, 0, ',', '.') ?>
                    </span>
                </div>

                <button
                    type="submit"
                    class="checkout-button"
                    onclick="return confirm('Apakah kamu yakin ingin membuat pesanan ini?');"
                >
                    Buat Pesanan
                </button>

            </form>

        </div>

    </div>

</div>

</body>
</html>
