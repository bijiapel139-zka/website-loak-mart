
<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

// ===================================
// PEMERIKSAAN LOGIN
// ===================================

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../user/barang-saya.php");
    exit;
}

// ===================================
// VALIDASI CSRF
// ===================================

if (!validasiCSRF()) {
    die("Permintaan tidak valid. Silakan muat ulang halaman.");
}

$userId = (int) $_SESSION['user']['id'];

$aksi = $_POST['aksi'] ?? '';


// ===================================
// FUNGSI REDIRECT
// ===================================

function kembali($pesan, $halaman = 'barang-saya.php')
{
    setFlash('error', $pesan);
    header("Location: ../user/" . $halaman);
    exit;
}


// ===================================
// FUNGSI UPLOAD FOTO
// ===================================

function uploadFoto()
{
    if (
        !isset($_FILES['foto']) ||
        $_FILES['foto']['error'] === UPLOAD_ERR_NO_FILE
    ) {
        return null;
    }

    if ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("Upload foto gagal.");
    }

    $file = $_FILES['foto'];

    // Maksimal 2 MB
    if ($file['size'] > 2 * 1024 * 1024) {
        throw new Exception("Ukuran foto maksimal 2 MB.");
    }

    // Memeriksa MIME type sebenarnya
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);

    $allowed = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($allowed[$mime])) {
        throw new Exception(
            "Format foto harus JPG, PNG, atau WEBP."
        );
    }

    // Nama file acak agar tidak bentrok
    $namaFile = bin2hex(random_bytes(16))
        . '.' . $allowed[$mime];

    $folder = __DIR__ . '/../uploads/barang/';

    if (!is_dir($folder)) {
        if (!mkdir($folder, 0755, true)) {
            throw new Exception("Folder upload tidak tersedia.");
        }
    }

    $tujuan = $folder . $namaFile;

    if (!move_uploaded_file($file['tmp_name'], $tujuan)) {
        throw new Exception("Gagal menyimpan foto.");
    }

    return $namaFile;
}


// ===================================
// FUNGSI HAPUS FOTO LAMA
// ===================================

function hapusFotoLama($namaFile)
{
    if (empty($namaFile)) {
        return;
    }

    // Hanya menerima nama file yang aman
    if (basename($namaFile) !== $namaFile) {
        return;
    }

    $path = __DIR__ . '/../uploads/barang/' . $namaFile;

    if (is_file($path)) {
        unlink($path);
    }
}


// ===================================
// AKSI TAMBAH BARANG
// ===================================

if ($aksi === 'tambah') {

    $nama = trim($_POST['nama_barang'] ?? '');
    $kategori = (int) ($_POST['kategori_id'] ?? 0);
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $hargaInput = $_POST['harga'] ?? '';
    $kondisi = $_POST['kondisi'] ?? '';
    $stokInput = $_POST['stok'] ?? '1';

    if ($nama === '' || strlen($nama) > 150) {
        kembali("Nama barang wajib diisi dan maksimal 150 karakter.", 'jual-barang.php');
    }

    if (!is_numeric($hargaInput) || (float)$hargaInput < 0) {
        kembali("Harga barang tidak valid.", 'jual-barang.php');
    }

    if (!ctype_digit((string)$stokInput) ||
        (int)$stokInput < 1 ||
        (int)$stokInput > 100000) {
        kembali("Stok minimal 1 dan maksimal 100000.", 'jual-barang.php');
    }

    $harga = (float) $hargaInput;
    $stok = (int) $stokInput;

    if (!in_array($kondisi, ['Baru', 'Bekas Bagus', 'Bekas Normal', 'Rusak'], true)) {
        kembali("Kondisi barang tidak valid.", 'jual-barang.php');
    }

    try {

        // Validasi kategori
        $cekKategori = $pdo->prepare(
            "SELECT id FROM kategori WHERE id = ?"
        );

        $cekKategori->execute([$kategori]);

        if (!$cekKategori->fetch()) {
            kembali("Kategori barang tidak ditemukan.", 'jual-barang.php');
        }

        $foto = uploadFoto();

        $sql = "INSERT INTO barang
                (user_id, kategori_id, nama_barang,
                deskripsi, harga, kondisi, stok, foto)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            $userId,
            $kategori,
            $nama,
            $deskripsi,
            $harga,
            $kondisi,
            $stok,
            $foto
        ]);

        setFlash('success', 'Barang berhasil ditambahkan!');

        header("Location: ../user/barang-saya.php");
        exit;

    } catch (Throwable $e) {

        if (!empty($foto)) {
        hapusFotoLama($foto);
        }

        error_log($e->getMessage());

        kembali(
        "Gagal menambahkan barang. Periksa data dan foto yang dimasukkan.",
        'jual-barang.php'
        );
    }
}


// ===================================
// AKSI EDIT BARANG
// ===================================

elseif ($aksi === 'edit') {

    $id = (int) ($_POST['id'] ?? 0);
    $nama = trim($_POST['nama_barang'] ?? '');
    $kategori = (int) ($_POST['kategori_id'] ?? 0);
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $hargaInput = $_POST['harga'] ?? '';
    $kondisi = $_POST['kondisi'] ?? '';
    $stokInput = $_POST['stok'] ?? '';

    if ($id <= 0 || $nama === '' || strlen($nama) > 150) {
        kembali("Data barang tidak valid.", 'barang-saya.php');
    }

    if (!is_numeric($hargaInput) || (float)$hargaInput < 0) {
        kembali("Harga barang tidak valid.", 'barang-saya.php');
    }

    if (!ctype_digit((string)$stokInput) ||
        (int)$stokInput < 1 ||
        (int)$stokInput > 100000) {
        kembali("Stok barang tidak valid.", 'barang-saya.php');
    }

    if (!in_array($kondisi, ['Baru', 'Bekas Bagus', 'Bekas Normal', 'Rusak'], true)) {
        kembali("Kondisi barang tidak valid.", 'barang-saya.php');
    }

    $fotoBaru = null;

    try {

        // Memastikan barang milik pengguna yang login
        $cek = $pdo->prepare(
            "SELECT foto FROM barang
             WHERE id = ? AND user_id = ?"
        );

        $cek->execute([$id, $userId]);

        $barangLama = $cek->fetch();

        if (!$barangLama) {
            kembali("Barang tidak ditemukan atau bukan milik Anda.");
        }

        $cekKategori = $pdo->prepare(
            "SELECT id FROM kategori WHERE id = ?"
        );

        $cekKategori->execute([$kategori]);

        if (!$cekKategori->fetch()) {
            kembali("Kategori tidak ditemukan.");
        }

        $fotoLama = $barangLama['foto'];

        // Upload foto jika pengguna memilih foto baru
        $fotoBaru = uploadFoto();

        $foto = $fotoBaru ?? $fotoLama;

        $sql = "UPDATE barang SET
                kategori_id = ?,
                nama_barang = ?,
                deskripsi = ?,
                harga = ?,
                kondisi = ?,
                stok = ?,
                foto = ?
                WHERE id = ? AND user_id = ?";

        $stmt = $pdo->prepare($sql);

        $stmt->execute([
            $kategori,
            $nama,
            $deskripsi,
            (float)$hargaInput,
            $kondisi,
            (int)$stokInput,
            $foto,
            $id,
            $userId
        ]);

        if ($fotoBaru !== null) {
            hapusFotoLama($fotoLama);
        }

        setFlash('success', 'Barang berhasil diperbarui.');

        header("Location: ../user/barang-saya.php");
        exit;

    } catch (Throwable $e) {

        if ($fotoBaru !== null) {
            hapusFotoLama($fotoBaru);
        }

        error_log($e->getMessage());

        kembali("Gagal memperbarui barang.", 'barang-saya.php');
    }
}


// ===================================
// AKSI HAPUS BARANG
// ===================================

elseif ($aksi === 'hapus') {

    $id = (int) ($_POST['id'] ?? 0);

    if ($id <= 0) {
        kembali("ID barang tidak valid.");
    }

    try {

        $cek = $pdo->prepare(
            "SELECT foto FROM barang
             WHERE id = ? AND user_id = ?"
        );

        $cek->execute([$id, $userId]);

        $barang = $cek->fetch();

        if (!$barang) {
            kembali("Barang tidak ditemukan atau bukan milik Anda.");
        }

        $hapus = $pdo->prepare(
            "DELETE FROM barang
             WHERE id = ? AND user_id = ?"
        );

        $hapus->execute([$id, $userId]);

        if ($hapus->rowCount() > 0) {
            hapusFotoLama($barang['foto']);
            setFlash('success', 'Barang berhasil dihapus.');
        }

        header("Location: ../user/barang-saya.php");
        exit;

    } catch (PDOException $e) {

        error_log($e->getMessage());

        kembali("Barang gagal dihapus.");
    }
}

else {
    kembali("Aksi tidak dikenali.");
}
