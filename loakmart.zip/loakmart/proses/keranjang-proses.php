
<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../index.php");
    exit;
}

if (!validasiCSRF()) {
    die("Permintaan tidak valid.");
}

$userId = (int)$_SESSION['user']['id'];
$aksi = $_POST['aksi'] ?? '';

function redirectKeranjang($pesan) {
    setFlash('error', $pesan);
    header("Location: ../user/keranjang.php");
    exit;
}

if ($aksi === 'tambah') {

    $barangId = (int)($_POST['barang_id'] ?? 0);
    $jumlah = filter_var(
        $_POST['jumlah'] ?? null,
        FILTER_VALIDATE_INT
    );

    if ($barangId <= 0 || $jumlah === false ||
        $jumlah === null || $jumlah < 1) {
        redirectKeranjang("Data barang tidak valid.");
    }

    try {

        $pdo->beginTransaction();

        $stmt = $pdo->prepare("
            SELECT id, user_id, stok, status
            FROM barang
            WHERE id = ?
            FOR UPDATE
        ");

        $stmt->execute([$barangId]);
        $barang = $stmt->fetch();

        if (!$barang || $barang['status'] !== 'tersedia') {
            throw new Exception("Barang tidak tersedia.");
        }

        if ((int)$barang['user_id'] === $userId) {
            throw new Exception("Anda tidak bisa membeli barang sendiri.");
        }

        $cek = $pdo->prepare("
            SELECT jumlah
            FROM keranjang
            WHERE user_id = ? AND barang_id = ?
        ");

        $cek->execute([$userId, $barangId]);
        $keranjang = $cek->fetch();

        $jumlahBaru = $jumlah +
            (int)($keranjang['jumlah'] ?? 0);

        if ($jumlahBaru > (int)$barang['stok']) {
            throw new Exception("Jumlah melebihi stok tersedia.");
        }

        if ($keranjang) {

            $update = $pdo->prepare("
                UPDATE keranjang
                SET jumlah = ?
                WHERE user_id = ? AND barang_id = ?
            ");

            $update->execute([
                $jumlahBaru,
                $userId,
                $barangId
            ]);

        } else {

            $insert = $pdo->prepare("
                INSERT INTO keranjang
                (user_id, barang_id, jumlah)
                VALUES (?, ?, ?)
            ");

            $insert->execute([
                $userId,
                $barangId,
                $jumlah
            ]);
        }

        $pdo->commit();

        setFlash('success', 'Barang berhasil ditambahkan ke keranjang.');

        header("Location: ../user/keranjang.php");
        exit;

    } catch (Throwable $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        error_log($e->getMessage());

        redirectKeranjang($e instanceof Exception
            ? $e->getMessage()
            : "Gagal menambahkan barang.");
    }

} elseif ($aksi === 'hapus') {

    $id = (int)($_POST['id'] ?? 0);

    $stmt = $pdo->prepare("
        DELETE FROM keranjang
        WHERE id = ? AND user_id = ?
    ");

    $stmt->execute([$id, $userId]);

    setFlash('success', 'Barang dihapus dari keranjang.');

    header("Location: ../user/keranjang.php");
    exit;

} else {

    redirectKeranjang("Aksi tidak dikenali.");
}
