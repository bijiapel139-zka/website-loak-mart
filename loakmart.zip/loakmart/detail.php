
<?php

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/auth.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    http_response_code(404);
    exit('Barang tidak ditemukan.');
}

$stmt = $pdo->prepare("
    SELECT
        barang.*,
        kategori.nama_kategori,
        users.nama AS nama_penjual
    FROM barang
    INNER JOIN kategori
        ON barang.kategori_id = kategori.id
    INNER JOIN users
        ON barang.user_id = users.id
    WHERE barang.id = ?
      AND barang.status = 'tersedia'
      AND barang.stok > 0
");

$stmt->execute([$id]);

$barang = $stmt->fetch();

if (!$barang) {
    http_response_code(404);
    exit('Barang tidak tersedia atau sudah habis.');
}

$isOwner = isset($_SESSION['user']) &&
    (int)$_SESSION['user']['id'] === (int)$barang['user_id'];

$pesan = getFlash('error');

?>

<!DOCTYPE html>
<html lang="id">
<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Detail Barang - LoakMart</title>

    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>

<header class="navbar">
    <div class="container nav-content">

        <a href="index.php" class="logo">
            Loak<span>Mart.</span>
        </a>

        <nav>
    <a href="index.php">Beranda</a>
    <a href="katalog.php">Katalog</a>

    <?php if (isset($_SESSION['user'])): ?>
        <a href="user/keranjang.php">Keranjang</a>
    <?php endif; ?>
</nav>

        <div class="nav-button">
            <?php if (isset($_SESSION['user'])): ?>
                <span>
                    Halo, <?= htmlspecialchars($_SESSION['user']['nama']) ?>
                </span>
            <?php else: ?>
                <a href="login.php" class="btn-login">Masuk</a>
            <?php endif; ?>
        </div>

    </div>
</header>

<section class="detail-section container">
    
    <a href="katalog.php" class="detail-back">
        &larr; Kembali ke Katalog
    </a>

    <div class="detail-card">

        <div class="detail-image">

            <?php if (!empty($barang['foto'])): ?>

                <img
                    src="uploads/barang/<?= rawurlencode($barang['foto']) ?>"
                    alt="<?= htmlspecialchars($barang['nama_barang']) ?>"
                >

            <?php else: ?>

                <div class="no-image">
                    Tidak ada foto
                </div>

            <?php endif; ?>

        </div>

        <div class="detail-info">

            <span class="product-category">
                <?= htmlspecialchars($barang['nama_kategori']) ?>
            </span>

            <h1>
                <?= htmlspecialchars($barang['nama_barang']) ?>
            </h1>

            <h2 class="detail-price">
                Rp <?= number_format($barang['harga'], 0, ',', '.') ?>
            </h2>

            <p>
                Kondisi:
                <strong><?= htmlspecialchars($barang['kondisi']) ?></strong>
            </p>

            <p>
                Stok tersedia:
                <strong><?= (int)$barang['stok'] ?></strong>
            </p>

            <p>
                Penjual:
                <strong><?= htmlspecialchars($barang['nama_penjual']) ?></strong>
            </p>

            <div class="detail-description">
                <h3>Deskripsi Barang</h3>

                <p>
                    <?= nl2br(htmlspecialchars($barang['deskripsi'] ?? 'Tidak ada deskripsi.')) ?>
                </p>
            </div>

            <?php if ($pesan): ?>
                <div class="alert">
                    <?= htmlspecialchars($pesan) ?>
                </div>
            <?php endif; ?>

            <?php if (!isset($_SESSION['user'])): ?>

                <a href="login.php" class="btn-primary">
                    Login untuk Membeli
                </a>

            <?php elseif ($isOwner): ?>

                <div class="alert">
                    Ini adalah barang milik Anda sendiri.
                </div>

            <?php else: ?>

                <form
                    action="proses/keranjang-proses.php"
                    method="POST"
                >

                    <input type="hidden" name="aksi" value="tambah">

                    <input
                        type="hidden"
                        name="barang_id"
                        value="<?= (int)$barang['id'] ?>"
                    >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"
                    >

                    <div class="form-group">
                        <label>Jumlah Pembelian</label>

                        <input
                            type="number"
                            name="jumlah"
                            value="1"
                            min="1"
                            max="<?= (int)$barang['stok'] ?>"
                            required
                        >
                    </div>

                    <button type="submit" class="seller-submit">
                        Tambahkan ke Keranjang
                    </button>

                </form>

            <?php endif; ?>

        </div>

    </div>

</section>

</body>
</html>
