
<?php
require_once '../config/database.php';
require_once '../config/auth.php';

wajibLogin();

if (($_SESSION['user']['role'] ?? '') !== 'admin') {
    header('Location: ../dashboard.php');
    exit;
}

$kataKunci = trim($_GET['cari'] ?? '');

if ($kataKunci !== '') {
    $stmt = $pdo->prepare("
        SELECT id, nama, email, role, status_akun
        FROM users
        WHERE nama LIKE ? OR email LIKE ?
        ORDER BY id DESC
    ");

    $pencarian = '%' . $kataKunci . '%';
    $stmt->execute([$pencarian, $pencarian]);
} else {
    $stmt = $pdo->query("
        SELECT id, nama, email, role, status_akun
        FROM users
        ORDER BY id DESC
    ");
}

$pengguna = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manajemen Pengguna - LoakMart</title>
    <link rel="stylesheet" href="../assets/css/style.css">

    <style>
        .admin-table-wrapper {
            overflow-x: auto;
            background: white;
            border-radius: 12px;
            padding: 15px;
            margin-top: 20px;
        }

        .admin-table {
            width: 100%;
            border-collapse: collapse;
            min-width: 650px;
        }

        .admin-table th,
        .admin-table td {
            padding: 13px;
            border-bottom: 1px solid #eee;
            text-align: left;
        }

        .admin-table th {
            background: #f5f5f5;
        }

        .admin-search {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 20px;
        }

        .admin-search input {
            flex: 1;
            min-width: 200px;
            padding: 11px;
        }

        .admin-search button,
        .admin-action button {
            padding: 10px 14px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .admin-action {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .admin-action button {
            background: #e8f1e9;
        }

        .admin-action .btn-nonaktif {
            background: #ffe5e5;
        }
    </style>
</head>
<body class="seller-body">

<div class="seller-container">

    <h2>Manajemen Pengguna</h2>
    <p>Kelola akun yang terdaftar di marketplace LoakMart.</p>

    <?php if ($pesan = getFlash('success')): ?>
        <p class="alert-success">
            <?= htmlspecialchars($pesan) ?>
        </p>
    <?php endif; ?>

    <?php if ($pesan = getFlash('error')): ?>
        <p class="alert-error">
            <?= htmlspecialchars($pesan) ?>
        </p>
    <?php endif; ?>

    <form method="GET" class="admin-search">
        <input
            type="text"
            name="cari"
            placeholder="Cari nama atau email..."
            value="<?= htmlspecialchars($kataKunci) ?>"
        >
        <button type="submit">Cari</button>
        <a href="pengguna.php">Reset</a>
    </form>

    <div class="admin-table-wrapper">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>

            <tbody>
            <?php if (!$pengguna): ?>
                <tr>
                    <td colspan="6">Pengguna tidak ditemukan.</td>
                </tr>
            <?php else: ?>

                <?php foreach ($pengguna as $i => $item): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>

                        <td>
                            <?= htmlspecialchars($item['nama']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($item['email']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($item['role']) ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($item['status_akun']) ?>
                        </td>

                        <td>
                            <?php if (
                                (int) $item['id'] ===
                                (int) $_SESSION['user']['id']
                                || $item['role'] === 'admin'
                            ): ?>
                                <span>Tidak dapat diubah</span>
                            <?php else: ?>

                                <form
                                    action="../proses/admin-pengguna-proses.php"
                                    method="POST"
                                    class="admin-action"
                                >
                                    <input type="hidden" name="csrf_token"
                                        value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

                                    <input type="hidden" name="user_id"
                                        value="<?= (int) $item['id'] ?>">

                                    <?php if ($item['status_akun'] === 'aktif'): ?>
                                        <input type="hidden" name="status_baru"
                                            value="nonaktif">

                                        <button
                                            type="submit"
                                            class="btn-nonaktif"
                                            onclick="return confirm('Nonaktifkan akun ini?')"
                                        >
                                            Nonaktifkan
                                        </button>
                                    <?php else: ?>
                                        <input type="hidden" name="status_baru"
                                            value="aktif">

                                        <button
                                            type="submit"
                                            onclick="return confirm('Aktifkan kembali akun ini?')"
                                        >
                                            Aktifkan
                                        </button>
                                    <?php endif; ?>
                                </form>

                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>

            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <p>
        <a href="../dashboard.php">Kembali ke Dashboard</a>
    </p>

</div>
</body>
</html>
