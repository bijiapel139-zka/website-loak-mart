
<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/auth.php';

// Mengambil kata pencarian dan kategori
$keyword = trim($_GET['cari'] ?? '');
$kategoriId = $_GET['kategori'] ?? '';

// Mengambil seluruh kategori
$stmtKategori = $pdo->query("
    SELECT id, nama_kategori
    FROM kategori
    ORDER BY nama_kategori ASC
");
$daftarKategori = $stmtKategori->fetchAll(PDO::FETCH_ASSOC);

// Query katalog barang
$sql = "
    SELECT 
        barang.*,
        kategori.nama_kategori,
        users.nama AS nama_penjual
    FROM barang
    INNER JOIN kategori
        ON barang.kategori_id = kategori.id
    LEFT JOIN users
        ON barang.user_id = users.id
    WHERE barang.status = 'tersedia'
      AND barang.stok > 0
";

$params = [];

// Filter pencarian
if ($keyword !== '') {
    $sql .= " AND barang.nama_barang LIKE ?";
    $params[] = "%$keyword%";
}

// Filter kategori
if ($kategoriId !== '' && ctype_digit((string)$kategoriId)) {
    $sql .= " AND barang.kategori_id = ?";
    $params[] = (int)$kategoriId;
}

$sql .= " ORDER BY barang.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$daftarBarang = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Menghitung jumlah barang
$totalBarang = count($daftarBarang);

// Fungsi keamanan output
function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Katalog Barang - LoakMart</title>

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/katalog.css">
</head>
<body>

<header class="navbar">
    <div class="nav-container">

        <a href="index.php" class="logo">
            Loak<span>Mart</span>
        </a>

        <nav class="nav-menu">
            <a href="index.php">Beranda</a>
            <a href="katalog.php" class="active">Katalog</a>

            <?php if (isset($_SESSION['user'])): ?>
                <a href="dashboard.php">Dashboard</a>
            <?php else: ?>
                <a href="login.php">Masuk</a>
            <?php endif; ?>
        </nav>

    </div>
</header>

<main class="katalog-container">

    <section class="katalog-heading">
        <span class="heading-label">BELANJA BARANG BEKAS BERKUALITAS</span>

        <h1>Temukan Barang <span>Favoritmu</span></h1>

        <p>
            Jelajahi berbagai barang loakan dengan harga terjangkau.
            Temukan barang yang masih layak pakai dan bermanfaat.
        </p>
    </section>

    <section class="filter-section">

        <form action="katalog.php" method="GET" class="filter-form">

            <div class="search-box">
                <span class="search-icon">⌕</span>

                <input
                    type="text"
                    name="cari"
                    placeholder="Cari nama barang..."
                    value="<?= e($keyword) ?>"
                >
            </div>

            <select name="kategori">
                <option value="">Semua Kategori</option>

                <?php foreach ($daftarKategori as $kategori): ?>
                    <option
                        value="<?= e($kategori['id']) ?>"
                        <?= ((string)$kategoriId === (string)$kategori['id']) ? 'selected' : '' ?>
                    >
                        <?= e($kategori['nama_kategori']) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit" class="btn-filter">
                Cari Barang
            </button>

            <a href="katalog.php" class="btn-reset">
                Reset
            </a>

        </form>

    </section>

    <section class="produk-section">

        <div class="produk-heading">
            <div>
                <h2>Katalog Barang</h2>
                <p>Barang pilihan yang tersedia di LoakMart.</p>
            </div>

            <span class="jumlah-produk">
                <?= $totalBarang ?> Barang ditemukan
            </span>
        </div>

        <?php if ($totalBarang > 0): ?>

            <div class="produk-grid">

                <?php foreach ($daftarBarang as $barang): ?>

                    <article class="produk-card">

                        <div class="produk-image">

                            <?php if (!empty($barang['foto'])): ?>

                                <img
                                    src="uploads/barang/<?= rawurlencode(basename($barang['foto'])) ?>"
                                    alt="<?= e($barang['nama_barang']) ?>"
                                    onerror="this.onerror=null;this.src='assets/images/no-image.png';"
                                >

                            <?php else: ?>

                                <div class="no-image">
                                    Foto tidak tersedia
                                </div>

                            <?php endif; ?>

                            <span class="kondisi-badge">
                                <?= e($barang['kondisi'] ?: 'Bekas') ?>
                            </span>

                        </div>

                        <div class="produk-info">

                            <span class="kategori-label">
                                <?= e($barang['nama_kategori']) ?>
                            </span>

                            <h3><?= e($barang['nama_barang']) ?></h3>

                            <div class="produk-harga">
                                Rp <?= number_format((float)$barang['harga'], 0, ',', '.') ?>
                            </div>

                            <p class="produk-stok">
                                Stok: <?= (int)$barang['stok'] ?>
                            </p>

                            <a
                                href="detail.php?id=<?= (int)$barang['id'] ?>"
                                class="btn-detail"
                            >
                                Lihat Detail
                            </a>

                        </div>

                    </article>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <div class="empty-product">
                <div class="empty-icon">⌕</div>

                <h3>Barang Tidak Ditemukan</h3>

                <p>
                    Maaf, barang yang kamu cari belum tersedia.
                    Coba gunakan kata kunci atau kategori lainnya.
                </p>

                <a href="katalog.php" class="btn-filter">
                    Lihat Semua Barang
                </a>
            </div>

        <?php endif; ?>

    </section>

</main>

<footer class="footer">
    <p>&copy; <?= date('Y') ?> LoakMart. Belanja Hemat, Barang Bermanfaat.</p>
</footer>

</body>
</html>
