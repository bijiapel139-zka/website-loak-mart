
<?php
require_once __DIR__ . '/config/auth.php';

if (sudahLogin()) {
    header("Location: index.php");
    exit;
}

$error = getFlash('error');
$success = getFlash('success');
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login - LoakMart</title>

    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-body">

<div class="auth-container">

    <div class="auth-card">

        <a href="index.php" class="logo auth-logo">
            Loak<span>Mart.</span>
        </a>

        <h2>Selamat Datang!</h2>

        <p class="auth-description">
            Masuk untuk mulai menggunakan LoakMart.
        </p>

        <?php if ($error): ?>
            <div class="alert">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success-alert">
                <?= htmlspecialchars($success) ?>
            </div>
        <?php endif; ?>

        <form action="proses/login-proses.php" method="POST">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"
            >

            <div class="form-group">
                <label>Email</label>
                <input
                    type="email"
                    name="email"
                    placeholder="Masukkan email"
                    required
                >
            </div>

            <div class="form-group">
                <label>Password</label>
                <input
                    type="password"
                    name="password"
                    placeholder="Masukkan password"
                    required
                >
            </div>

            <button type="submit" class="auth-button">
                Masuk Sekarang
            </button>

        </form>

        <p class="auth-footer">
            Belum punya akun?
            <a href="register.php">Daftar sekarang</a>
        </p>

    </div>

</div>

</body>
</html>
