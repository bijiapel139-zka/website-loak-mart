
<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

wajibLogin();

$userId = (int)$_SESSION['user']['id'];

$stmt = $pdo->prepare("
    SELECT
        keranjang.id AS keranjang_id,
        keranjang.jumlah,
        barang.id AS barang_id,
        barang.nama_barang,
        barang.harga,
        barang.foto,
        barang.stok,
        users.nama AS nama_penjual
    FROM keranjang
    INNER JOIN barang
        ON keranjang.barang_id = barang.id
    INNER JOIN users
        ON barang.user_id = users.id
    WHERE keranjang.user_id = ?
      AND barang.status = 'tersedia'
      AND barang.stok > 0
    ORDER BY keranjang.created_at DESC
");

$stmt->execute([$userId]);

$barang = $stmt->fetchAll();

$total = 0;

$pesan = getFlash('error');
$success = getFlash('success');

?>

<!DOCTYPE html>
<html lang="id">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Keranjang - LoakMart</title>

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body class="seller-body">

<div class="seller-container">

    <div class="seller-header">

        <div>
            <a href="../index.php" class="logo">
                Loak<span>Mart.</span>
            </a>

            <h2>Keranjang Belanja</h2>

            <p>Periksa barang pilihanmu sebelum checkout.</p>
        </div>

        <a href="../index.php" class="back-button">
            Lanjut Belanja
        </a>

    </div>

    <?php if ($pesan): ?>
        <div class="alert">
            <?= htmlspecialchars($pesan) ?>
        </div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="success-alert">
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <?php if (count($barang) > 0): ?>

        <div class="cart-list">

            <?php foreach ($barang as $item): ?>

                <?php
                $subtotal = $item['harga'] * $item['jumlah'];
                $total += $subtotal;
                ?>

                <div class="cart-item">

                    <?php if (!empty($item['foto'])): ?>

                        <img
                            src="../uploads/barang/<?= rawurlencode($item['foto']) ?>"
                            alt="<?= htmlspecialchars($item['nama_barang']) ?>"
                        >

                    <?php else: ?>

                        <div class="no-image">
                            Tidak ada foto
                        </div>

                    <?php endif; ?>

                    <div class="cart-info">

                        <h3>
                            <?= htmlspecialchars($item['nama_barang']) ?>
                        </h3>

                        <p>
                            Penjual:
                            <?= htmlspecialchars($item['nama_penjual']) ?>
                        </p>

                        <p>
                            Harga:
                            Rp <?= number_format($item['harga'], 0, ',', '.') ?>
                        </p>

                        <p>
                            Jumlah:
                            <?= (int)$item['jumlah'] ?>
                        </p>

                        <strong>
                            Subtotal:
                            Rp <?= number_format($subtotal, 0, ',', '.') ?>
                        </strong>

                        <form
                            action="../proses/keranjang-proses.php"
                            method="POST"
                            onsubmit="return confirm('Hapus barang dari keranjang?')"
                        >

                            <input
                                type="hidden"
                                name="aksi"
                                value="hapus"
                            >

                            <input
                                type="hidden"
                                name="id"
                                value="<?= (int)$item['keranjang_id'] ?>"
                            >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"
                            >

                            <button type="submit" class="delete-button">
                                Hapus
                            </button>

                        </form>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

        <div class="cart-summary">

            <h3>
                Total:
                Rp <?= number_format($total, 0, ',', '.') ?>
            </h3>

            <a href="checkout.php" class="seller-submit">
                Lanjut Checkout
            </a>

        </div>

    <?php else: ?>

        <div class="empty-state">
            <h3>Keranjang Masih Kosong</h3>

            <p>Silakan pilih barang yang ingin kamu beli.</p>

            <a href="../index.php" class="add-button">
                Cari Barang
            </a>
        </div>

    <?php endif; ?>
    
    <a href="dashboard.php">Kembali ke Dashboard</a>

</div>

</body>
</html>
