
<?php

require_once __DIR__ . '/database.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Membuat token CSRF jika belum tersedia.
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Membuat URL berdasarkan lokasi folder proyek.
function urlLoakMart($file = '')
{
    $direktori = str_replace(
        '\\',
        '/',
        dirname($_SERVER['SCRIPT_NAME'] ?? '')
    );

    $direktori = rtrim($direktori, '/');

    // Jika berada di subfolder user, admin, atau proses.
    if (preg_match('~/(user|admin|proses)$~i', $direktori)) {
        $posisi = strrpos($direktori, '/');

        $direktori = ($posisi === false)
            ? ''
            : substr($direktori, 0, $posisi);
    }

    return $direktori . '/' . ltrim($file, '/');
}

// Memeriksa apakah pengguna sudah login.
function sudahLogin()
{
    return isset($_SESSION['user']['id']);
}

// Mengakhiri session autentikasi.
function hapusSessionLogin()
{
    unset($_SESSION['user']);

    // Membuat token CSRF baru.
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    // Mengganti ID session.
    session_regenerate_id(true);
}

// Melindungi halaman yang membutuhkan login.
function wajibLogin()
{
    global $pdo;

    if (!sudahLogin()) {
        header('Location: ' . urlLoakMart('login.php'));
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT status_akun
            FROM users
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            (int) $_SESSION['user']['id']
        ]);

        $statusAkun = $stmt->fetchColumn();

        // Jika akun tidak ditemukan atau nonaktif.
        if ($statusAkun !== 'aktif') {

            hapusSessionLogin();

            setFlash(
                'error',
                'Akun Anda sudah dinonaktifkan atau tidak ditemukan. Silakan hubungi administrator.'
            );

            header('Location: ' . urlLoakMart('login.php'));
            exit;
        }

    } catch (PDOException $e) {

        error_log(
            'Pemeriksaan akun LoakMart: ' . $e->getMessage()
        );

        http_response_code(500);

        exit(
            'Terjadi kesalahan saat memeriksa akun. Silakan coba kembali.'
        );
    }
}

// Membatasi akses berdasarkan role.
function wajibRole($role)
{
    wajibLogin();

    if (($_SESSION['user']['role'] ?? '') !== $role) {
        header('Location: ' . urlLoakMart('dashboard.php'));
        exit;
    }
}

// Menyimpan pesan sementara.
function setFlash($key, $message)
{
    $_SESSION['flash'][$key] = $message;
}

// Mengambil dan menghapus pesan sementara.
function getFlash($key)
{
    if (isset($_SESSION['flash'][$key])) {
        $message = $_SESSION['flash'][$key];

        unset($_SESSION['flash'][$key]);

        return $message;
    }

    return null;
}

// Memvalidasi token CSRF.
function validasiCSRF()
{
    return isset(
        $_POST['csrf_token'],
        $_SESSION['csrf_token']
    ) && hash_equals(
        $_SESSION['csrf_token'],
        $_POST['csrf_token']
    );
}
