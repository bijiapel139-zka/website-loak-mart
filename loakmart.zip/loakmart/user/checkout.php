
<?php
require_once '../config/database.php';
require_once '../config/auth.php';

wajibLogin();

$userId = (int) $_SESSION['user']['id'];

$stmt = $pdo->prepare("
    SELECT k.jumlah, b.id, b.nama_barang, b.harga, b.stok,
           b.foto, u.nama AS nama_penjual
    FROM keranjang k
    JOIN barang b ON b.id = k.barang_id
    JOIN users u ON u.id = b.user_id
    WHERE k.user_id = ?
      AND b.status = 'tersedia'
      AND b.stok > 0
    ORDER BY b.id
");
$stmt->execute([$userId]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$items) {
    setFlash('error', 'Keranjang masih kosong atau barang tidak tersedia.');
    header('Location: keranjang.php');
    exit;
}

$total = 0;
foreach ($items as $item) {
    $total += (float) $item['harga'] * (int) $item['jumlah'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Checkout - LoakMart</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="seller-body">
<div class="seller-container">
    <h2>Checkout Pesanan</h2>

    <div class="seller-card">
        <h3>Ringkasan Pesanan</h3>

        <?php foreach ($items as $item): ?>
            <p>
                <?= htmlspecialchars($item['nama_barang']) ?>
                (<?= (int) $item['jumlah'] ?> x
                Rp<?= number_format($item['harga'], 0, ',', '.') ?>)
            </p>
        <?php endforeach; ?>

        <hr>
        <h3>Total:
            Rp<?= number_format($total, 0, ',', '.') ?>
        </h3>
    </div>

    <form action="../proses/checkout-proses.php"
          method="POST" class="seller-card">

        <input type="hidden" name="csrf_token"
               value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

        <label>Alamat Pengiriman</label>
        <textarea name="alamat_pengiriman"
                  required maxlength="2000"
                  placeholder="Masukkan alamat lengkap"></textarea>

        <label>Nomor HP</label>
        <input type="tel" name="no_hp"
               required maxlength="20"
               placeholder="Contoh: 081234567890">

        <label>Metode Pembayaran</label>
        <select name="metode_pembayaran" required>
            <option value="COD">COD (Bayar di Tempat)</option>
            <option value="Transfer Manual">Transfer Manual</option>
        </select>

        <button type="submit" class="seller-submit"
                onclick="return confirm('Yakin ingin membuat pesanan?')">
            Konfirmasi Pesanan
        </button>

        <a href="dashboard.php">Kembali ke Dashboard</a>
    </form>
</div>
</body>
</html>
