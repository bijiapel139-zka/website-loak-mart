<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: ../login.php");
    exit;
}

if (!validasiCSRF()) {
    die("Permintaan tidak valid. Silakan muat ulang halaman.");
}

$email = strtolower(trim($_POST['email'] ?? ''));
$password = $_POST['password'] ?? '';

if ($email === '' || $password === '') {
    setFlash('error', 'Email dan password wajib diisi.');
    header("Location: ../login.php");
    exit;
}

try {
    // Ambil data akun, termasuk status akun.
    $stmt = $pdo->prepare("
        SELECT id, nama, email, password, role, status_akun
        FROM users
        WHERE email = ?
        LIMIT 1
    ");

    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Periksa email dan password.
    if (!$user || !password_verify($password, $user['password'])) {
        setFlash('error', 'Email atau password salah.');
        header("Location: ../login.php");
        exit;
    }

    // Tolak akun yang sudah dinonaktifkan.
    if ($user['status_akun'] !== 'aktif') {
        setFlash(
            'error',
            'Akun Anda sedang dinonaktifkan. Silakan hubungi administrator.'
        );

        header("Location: ../login.php");
        exit;
    }

    // Perbarui ID session setelah login berhasil.
    session_regenerate_id(true);

    // Simpan informasi pengguna.
    $_SESSION['user'] = [
        'id' => $user['id'],
        'nama' => $user['nama'],
        'email' => $user['email'],
        'role' => $user['role'],
        'status_akun' => $user['status_akun']
    ];

    // Buat token CSRF baru.
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

    header("Location: ../dashboard.php");
    exit;

} catch (PDOException $e) {

    error_log('Login LoakMart: ' . $e->getMessage());

    setFlash('error', 'Terjadi kesalahan sistem.');
    header("Location: ../login.php");
    exit;
}
