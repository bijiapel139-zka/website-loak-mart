
<?php
require_once __DIR__ . '/config/auth.php';

if (sudahLogin()) {
    header("Location: index.php");
    exit;
}

$pesan = getFlash('error');
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Daftar Akun - LoakMart</title>

    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-body">

<div class="auth-container">

    <div class="auth-card">

        <a href="index.php" class="logo auth-logo">
            Loak<span>Mart.</span>
        </a>

        <h2>Buat Akun Baru</h2>

        <p class="auth-description">
            Bergabung dan mulai jual beli barang loakan.
        </p>

        <?php if ($pesan): ?>
            <div class="alert">
                <?= htmlspecialchars($pesan) ?>
            </div>
        <?php endif; ?>

        <form action="proses/register-proses.php" method="POST">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"
            >

            <div class="form-group">
                <label>Nama Lengkap</label>
                <input
                    type="text"
                    name="nama"
                    placeholder="Masukkan nama lengkap"
                    maxlength="100"
                    required
                >
            </div>

            <div class="form-group">
                <label>Email</label>
                <input
                    type="email"
                    name="email"
                    placeholder="contoh@email.com"
                    maxlength="100"
                    required
                >
            </div>

            <div class="form-group">
                <label>Nomor HP</label>
                <input
                    type="tel"
                    name="no_hp"
                    placeholder="08xxxxxxxxxx"
                    maxlength="20"
                >
            </div>

            <div class="form-group">
                <label>Alamat</label>
                <textarea
                    name="alamat"
                    placeholder="Masukkan alamat"
                ></textarea>
            </div>

            <div class="form-group">
                <label>Password</label>
                <input
                    type="password"
                    name="password"
                    placeholder="Minimal 8 karakter"
                    minlength="8"
                    required
                >
            </div>

            <div class="form-group">
                <label>Konfirmasi Password</label>
                <input
                    type="password"
                    name="konfirmasi_password"
                    placeholder="Ulangi password"
                    minlength="8"
                    required
                >
            </div>

            <button type="submit" class="auth-button">
                Daftar Sekarang
            </button>

        </form>

        <p class="auth-footer">
            Sudah punya akun?
            <a href="login.php">Masuk di sini</a>
        </p>

    </div>

</div>

</body>
</html>
