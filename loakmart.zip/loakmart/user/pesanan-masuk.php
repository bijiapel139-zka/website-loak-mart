
<?php
require_once '../config/database.php';
require_once '../config/auth.php';

wajibLogin();

$userId = (int) $_SESSION['user']['id'];

$stmt = $pdo->prepare("
    SELECT
        dt.id AS detail_id,
        dt.transaksi_id,
        dt.nama_barang,
        dt.harga,
        dt.jumlah,
        dt.subtotal,
        dt.status_item,
        t.kode_transaksi,
        t.alamat_pengiriman,
        t.no_hp,
        t.metode_pembayaran,
        t.created_at,
        u.nama AS nama_pembeli
    FROM detail_transaksi dt
    JOIN transaksi t ON t.id = dt.transaksi_id
    JOIN users u ON u.id = t.pembeli_id
    WHERE dt.penjual_id = ?
    ORDER BY t.created_at DESC, dt.id DESC
");

$stmt->execute([$userId]);
$pesanan = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pesanan Masuk - LoakMart</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="seller-body">

<div class="seller-container">
    <h2>Pesanan Masuk</h2>
    <p>Daftar barang yang dipesan oleh pembeli dari toko Anda.</p>

    <?php if ($pesan = getFlash('success')): ?>
        <p class="alert-success">
            <?= htmlspecialchars($pesan) ?>
        </p>
    <?php endif; ?>

    <?php if ($pesan = getFlash('error')): ?>
        <p class="alert-error">
            <?= htmlspecialchars($pesan) ?>
        </p>
    <?php endif; ?>

    <?php if (!$pesanan): ?>
        <div class="seller-card">
            <p>Belum ada pesanan masuk.</p>
        </div>
    <?php else: ?>

        <?php foreach ($pesanan as $item): ?>
            <div class="seller-card">
                <h3>
                    <?= htmlspecialchars($item['nama_barang']) ?>
                </h3>

                <p>
                    Kode transaksi:
                    <?= htmlspecialchars($item['kode_transaksi']) ?>
                </p>

                <p>
                    Pembeli:
                    <?= htmlspecialchars($item['nama_pembeli']) ?>
                </p>

                <p>
                    Jumlah:
                    <?= (int) $item['jumlah'] ?>
                </p>

                <p>
                    Subtotal:
                    Rp<?= number_format($item['subtotal'], 0, ',', '.') ?>
                </p>

                <p>
                    Alamat:
                    <?= nl2br(htmlspecialchars($item['alamat_pengiriman'])) ?>
                </p>

                <p>
                    Nomor HP:
                    <?= htmlspecialchars($item['no_hp']) ?>
                </p>

                <p>
                    Pembayaran:
                    <?= htmlspecialchars($item['metode_pembayaran']) ?>
                </p>

                <p>
                    Status:
                    <strong>
                        <?= htmlspecialchars($item['status_item']) ?>
                    </strong>
                </p>

                <?php if ($item['status_item'] === 'menunggu' ||
                          $item['status_item'] === 'diproses'): ?>

                    <form action="../proses/pesanan-proses.php"
                          method="POST">

                        <input type="hidden" name="csrf_token"
                               value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">

                        <input type="hidden" name="detail_id"
                               value="<?= (int) $item['detail_id'] ?>">

                        <?php if ($item['status_item'] === 'menunggu'): ?>
                            <input type="hidden" name="status_baru"
                                   value="diproses">
                            <button type="submit" class="seller-submit">
                                Proses Pesanan
                            </button>
                        <?php else: ?>
                            <input type="hidden" name="status_baru"
                                   value="dikirim">
                            <button type="submit" class="seller-submit">
                                Tandai Dikirim
                            </button>
                        <?php endif; ?>
                    </form>

                <?php endif; ?>
            </div>
        <?php endforeach; ?>

    <?php endif; ?>

    <a href="dashboard.php">Kembali ke Dashboard</a>
</div>

</body>
</html>
