
<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

if (!isset($_SESSION['user'])) {
    header("Location: ../login.php");
    exit;
}

$pesan = getFlash('error');

$stmt = $pdo->query(
    "SELECT * FROM kategori ORDER BY nama_kategori ASC"
);

$kategori = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Jual Barang - LoakMart</title>

    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="seller-body">

<div class="seller-container">

    <div class="seller-header">
        <div>
            <a href="../index.php" class="logo">
                Loak<span>Mart.</span>
            </a>

            <h2>Jual Barang</h2>

            <p>Pasang barang loakan yang ingin kamu jual.</p>
        </div>

        <a href="barang-saya.php" class="back-button">
            Barang Saya
        </a>
    </div>

    <div class="seller-card">

        <?php if ($pesan): ?>
            <div class="alert">
                <?= htmlspecialchars($pesan) ?>
            </div>
        <?php endif; ?>

        <form
            action="../proses/barang-proses.php"
            method="POST"
            enctype="multipart/form-data"
        >

            <input type="hidden" name="aksi" value="tambah">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>"
            >

            <div class="form-group">
                <label>Nama Barang</label>

                <input
                    type="text"
                    name="nama_barang"
                    placeholder="Contoh: Besi bekas"
                    maxlength="150"
                    required
                >
            </div>

            <div class="form-group">
                <label>Kategori Barang</label>

                <select name="kategori_id" required>
                    <option value="">Pilih kategori</option>

                    <?php foreach ($kategori as $k): ?>

                        <option value="<?= (int)$k['id'] ?>">
                            <?= htmlspecialchars($k['nama_kategori']) ?>
                        </option>

                    <?php endforeach; ?>

                </select>
            </div>

            <div class="form-group">
                <label>Deskripsi Barang</label>

                <textarea
                    name="deskripsi"
                    placeholder="Jelaskan kondisi dan informasi barang..."
                    rows="5"
                ></textarea>
            </div>

            <div class="form-group">
                <label>Harga Barang (Rp)</label>

                <input
                    type="number"
                    name="harga"
                    min="0"
                    step="0.01"
                    placeholder="Contoh: 50000"
                    required
                >
            </div>

            <div class="form-group">
                <label>Kondisi Barang</label>

                <select name="kondisi" required>

                    <option value="">Pilih kondisi</option>
                    <option value="Baru">Baru</option>
                    <option value="Bekas Bagus">Bekas Bagus</option>
                    <option value="Bekas Normal">Bekas Normal</option>
                    <option value="Rusak">Rusak</option>

                </select>
            </div>

            <div class="form-group">
                <label>Jumlah Stok</label>

                <input
                    type="number"
                    name="stok"
                    min="1"
                    max="100000"
                    value="1"
                    required
                >
            </div>

            <div class="form-group">
                <label>Foto Barang</label>

                <input
                    type="file"
                    name="foto"
                    accept=".jpg,.jpeg,.png,.webp"
                >

                <small>
                    Format JPG, PNG, WEBP. Maksimal 2 MB.
                </small>
            </div>

            <button type="submit" class="seller-submit">
                Publikasikan Barang
            </button>

        </form>

    </div>

</div>

</body>
</html>
