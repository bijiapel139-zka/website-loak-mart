
<?php
require_once '../config/database.php';
require_once '../config/auth.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function kembaliPesanan($pesan) {
    setFlash('error', $pesan);
    header('Location: ../user/pesanan-masuk.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../user/pesanan-masuk.php');
    exit;
}

if (empty($_SESSION['user']['id'])) {
    header('Location: ../login.php');
    exit;
}

if (!validasiCSRF()) {
    kembaliPesanan('Permintaan tidak valid.');
}

$userId = (int) $_SESSION['user']['id'];
$detailId = filter_input(INPUT_POST, 'detail_id', FILTER_VALIDATE_INT);
$statusBaru = $_POST['status_baru'] ?? '';

if (!$detailId || !in_array($statusBaru, ['diproses', 'dikirim'], true)) {
    kembaliPesanan('Data pesanan tidak valid.');
}

try {
    $pdo->beginTransaction();

    // Pastikan barang pesanan memang milik penjual yang login.
    $stmt = $pdo->prepare("
        SELECT id, transaksi_id, status_item
        FROM detail_transaksi
        WHERE id = ? AND penjual_id = ?
        FOR UPDATE
    ");
    $stmt->execute([$detailId, $userId]);
    $detail = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$detail) {
        throw new Exception('Pesanan tidak ditemukan.');
    }

    // Batasi perubahan status agar tidak bisa melompati tahapan.
    $transisiDiizinkan = [
        'menunggu' => 'diproses',
        'diproses' => 'dikirim'
    ];

    if (
        !isset($transisiDiizinkan[$detail['status_item']]) ||
        $transisiDiizinkan[$detail['status_item']] !== $statusBaru
    ) {
        throw new Exception('Perubahan status tidak diizinkan.');
    }

    $stmt = $pdo->prepare("
        UPDATE detail_transaksi
        SET status_item = ?
        WHERE id = ? AND penjual_id = ?
    ");
    $stmt->execute([$statusBaru, $detailId, $userId]);

    // Sinkronkan status transaksi utama berdasarkan seluruh barang.
    $stmt = $pdo->prepare("
        SELECT
            COUNT(*) AS jumlah_item,
            SUM(status_item = 'selesai') AS jumlah_selesai,
            SUM(status_item = 'dikirim') AS jumlah_dikirim,
            SUM(status_item = 'diproses') AS jumlah_diproses
        FROM detail_transaksi
        WHERE transaksi_id = ?
    ");
    $stmt->execute([(int) $detail['transaksi_id']]);
    $rekap = $stmt->fetch(PDO::FETCH_ASSOC);

    if ((int) $rekap['jumlah_selesai'] === (int) $rekap['jumlah_item']) {
        $statusTransaksi = 'selesai';
    } elseif ((int) $rekap['jumlah_dikirim'] > 0) {
        $statusTransaksi = 'dikirim';
    } elseif ((int) $rekap['jumlah_diproses'] > 0) {
        $statusTransaksi = 'diproses';
    } else {
        $statusTransaksi = 'menunggu';
    }

    $stmt = $pdo->prepare("
        UPDATE transaksi
        SET status = ?
        WHERE id = ?
    ");
    $stmt->execute([
        $statusTransaksi,
        (int) $detail['transaksi_id']
    ]);

    $pdo->commit();

    setFlash('success', 'Status pesanan berhasil diperbarui.');
    header('Location: ../user/pesanan-masuk.php');
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log('Status pesanan LoakMart: ' . $e->getMessage());

    kembaliPesanan(
        $e instanceof Exception
            ? $e->getMessage()
            : 'Gagal memperbarui status pesanan.'
    );
}
