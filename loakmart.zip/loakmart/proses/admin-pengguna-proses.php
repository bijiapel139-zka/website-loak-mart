
<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth.php';

// Fungsi untuk kembali ke halaman pengguna
function kembaliPengguna($pesan, $jenis = 'error')
{
    setFlash($jenis, $pesan);
    header('Location: ../admin/pengguna.php');
    exit;
}

// Hanya menerima POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../admin/pengguna.php');
    exit;
}

// Pastikan hanya admin aktif yang dapat mengakses
wajibRole('admin');

// Validasi CSRF
if (!validasiCSRF()) {
    kembaliPengguna('Permintaan tidak valid. Silakan muat ulang halaman.');
}

// Ambil data
$userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
$statusBaru = $_POST['status_baru'] ?? '';
$adminId = (int) $_SESSION['user']['id'];

// Validasi input
if (!$userId || !in_array($statusBaru, ['aktif', 'nonaktif'], true)) {
    kembaliPengguna('Data pengguna tidak valid.');
}

// Admin tidak boleh mengubah status akunnya sendiri
if ((int) $userId === $adminId) {
    kembaliPengguna('Anda tidak dapat menonaktifkan akun sendiri.');
}

try {

    // Periksa apakah pengguna tersedia dan bukan admin
    $cek = $pdo->prepare("
        SELECT id, role, status_akun
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $cek->execute([$userId]);
    $pengguna = $cek->fetch(PDO::FETCH_ASSOC);

    if (!$pengguna) {
        kembaliPengguna('Pengguna tidak ditemukan.');
    }

    if ($pengguna['role'] === 'admin') {
        kembaliPengguna('Status akun administrator tidak dapat diubah.');
    }

    if ($pengguna['status_akun'] === $statusBaru) {
        kembaliPengguna('Status akun sudah sesuai.', 'success');
    }

    // Perbarui status akun
    $stmt = $pdo->prepare("
        UPDATE users
        SET status_akun = ?
        WHERE id = ?
          AND role <> 'admin'
    ");

    $stmt->execute([$statusBaru, $userId]);

    setFlash('success', 'Status akun berhasil diperbarui.');

    header('Location: ../admin/pengguna.php');
    exit;

} catch (PDOException $e) {

    error_log('Manajemen pengguna LoakMart: ' . $e->getMessage());

    kembaliPengguna('Terjadi kesalahan saat memperbarui akun.');
}
